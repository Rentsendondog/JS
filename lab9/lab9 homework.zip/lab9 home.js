window.alert("bolj bna9h");

//-------------------Bodlogo:1------------------

 document.writeln("<h2> 1 - р Бодлого:  1. Хэрэглэгчээс n тоог гараас авч 1-ээс n хүртэлх тоонуудын квадрат, куб зэргүүдийг олж дараах хүснэгт хэлбэрээр HTML5 документэд харуул.</h2>");

 var number, square, cube;
 n = window.prompt("  1 - р Бодлого: Тоог өг n:  ");
   n = parseInt(n);

   document.writeln("<table>" ); // хүснэгт эхлэж байна

		 // ----------гарчиг------------
		 document.writeln( "<h3>1. Бодлого </h3>" );
        // ------------толгой хэсэг---------------
		 document.writeln( "<thead><tr><th>number</th>" ); 
		 document.writeln( "<th>square</th>" ); 
		 document.writeln( "<th>cube</th>" ); 
		 document.writeln( "</tr></thead><tbody>" );

 for(number = 0 ; number <= n; number++)
 {
 	 square = number * number;
 	 cube = number * number * number;
 	 document.writeln( "<tr class='oddrow'><td>" + number +
		 			"</td><td>" + square + "</td><td>" + cube + "</td></tr>" );
 }

 document.writeln( "</tbody></table>" );

 //-------------------Bodlogo:2------------------

     document.writeln("<h2> 2 - р Бодлого: Палиндром гэдэг нь араасаа болон урдаасаа ижил уншдаг тоо эсвэл текст юм. Жишээлбэл дараах таван оронтой тоонууд нь бүгд палиндром юм: 12321, 55555, 45554, 11611. Хэрэглэгчээс 5 оронтой тоог аваад палиндром эсэхийг тодорхойл. Хэрвээ хэрэглэгч 5-с өөр оронтой тоо оруулбал alert цонхоор анхааруулах мэдээлэл гарга. Хэрэглэгч alert цонхыг хаахад шинэ утга оруулах prompt цонхыг дахин гарга.</h2>");
     var n, m, p ,s;

     while(true)
     {
	      n = window.prompt("  2 - р Бодлого: n тоог өг: ");
            n = parseInt(n);
	        m = n; 
	        p = 0;
	        while(m > 0)
            {
	            m /= 10;
	            p++;
	            m = Math.floor(m);
            }

            if(p == 5)
    	          break;
	   
            else
    	         window.alert("Зөвхөн 5 оронтой тоо оруул!!!");
     }

	 k = n;
	 s = 0;
	 while(k > 0)
	 {
		 s = s * 10 + k % 10;
		 k = k / 10;
		 k = Math.floor(k);
	 }

	if(n == s)
		document.writeln("<p> Палиндром тоо:  " + n + "</p>");
	else 
		document.writeln("<p> Палиндром тоо биш:  " + n + "</p>");


//-------------------Bodlogo:3------------------

    document.writeln("<h2> 3 - р Бодлого: Палиндром гэдэг нь араасаа болон урдаасаа ижил уншдаг тоо эсвэл текст юм. Жишээлбэл дараах таван оронтой тоонууд нь бүгд палиндром юм: 12321, 55555, 45554, 11611. Хэрэглэгчээс 5 оронтой тоог аваад палиндром эсэхийг тодорхойл. Хэрвээ хэрэглэгч 5-с өөр оронтой тоо оруулбал alert цонхоор анхааруулах мэдээлэл гарга. Хэрэглэгч alert цонхыг хаахад шинэ утга оруулах prompt цонхыг дахин гарга.</h2>");
    var n, m, p, r, q, s, s2;
    var a, b, c, d, temp1, temp2;

    while(true)
    {
	    n = window.prompt("  2 - р Бодлого: n тоог өг: ");
          n = parseInt(n);
	      m = n; 
	      p = 0;
	      while(m > 0)
          {
	           m /= 10;
	           p++;
	           m = Math.floor(m);
           }

           if(p == 4)
    	        break;
	   
           else
    	        window.alert("Зөвхөн 4 оронтой тоо шифрлэх боломжтой учир 4 оронтой тоо оруул!!!");
     }

     a = Math.floor(n / 1000);
     a = (a + 7) % 10;

     b = Math.floor(n / 100) % 10;
     b = (b + 7) % 10;

     c = Math.floor((n % 100) / 10);
     c = (c + 7) % 10;

     d = n % 10;
     d = (d + 7) % 10;

     temp1 = a;
     a = c;
     c = temp1;

     temp2 = b;
     b = d;
     d = temp2;


     document.writeln("<h3> Шифрлэгдсэн тоо:  " + a + b + c + d + "</h3>");











 
 


